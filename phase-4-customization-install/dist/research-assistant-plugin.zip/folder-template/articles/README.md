Article PDFs go here. Drop them in, or let Claude save the open-access copies it finds.
