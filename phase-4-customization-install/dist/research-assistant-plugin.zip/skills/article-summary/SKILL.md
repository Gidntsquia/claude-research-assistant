---
name: article-summary
description: Summarize journal articles with a page number and a word-for-word quote behind every key detail. Use whenever the user pastes a DOI or an article link, drags in or mentions PDF files, asks about articles in the folder, asks for an article from Zotero, or asks to summarize, compare or "tell me the key details" of a paper.
---

# Summarizing articles

The reader is a professor of archaeology. He uses the summary to decide what an article says and whether to trust it, so every key detail must be checkable against the page it came from. An unsupported sentence is worse than a missing one.

## 1. Get the article

**A DOI or a link.** Find the DOI (in the link, or on the page the link opens). Fetch `https://api.openalex.org/works/doi:<DOI>` and read `open_access.is_oa`, `open_access.oa_url` and the `locations` list.

- **An open copy exists** (`is_oa` is true): fetch `oa_url` and read the whole article. If that address refuses (an error, a login page, a page with no article text), try the other entries in `locations` where `is_oa` is true, `pdf_url` first, before giving up. When the copy is a PDF, save it in the folder's `articles/` as `<first author>-<year>-<two or three title words>.pdf` and read it page by page, so that page numbers are real.
- **No open copy** (`is_oa` is false): do not go looking for another route. Reply in this shape and stop:
  1. First line: `This article is paywalled: OpenAlex lists no open copy.`
  2. Title, authors, year, journal.
  3. `Abstract (from OpenAlex, not from the article itself):` then the abstract. OpenAlex stores it as `abstract_inverted_index` (each word with its positions); put the words back in order. If OpenAlex has none, fetch `https://api.crossref.org/works/<DOI>` and use its `abstract`. If neither has one, say "No abstract is available from OpenAlex or Crossref."
  4. Ask him to download the PDF through his library and drag it into the chat or the folder. One line: if his library offers LibKey Nomad, its "Download PDF" button does this in one click.
  Never write the seven sections from an abstract, and never guess what a paywalled article says.
- **An open copy is listed but every address refused**: say exactly that (it is not paywalled), give him the link to click, and ask him to drop the downloaded PDF in.

**PDFs he drags in or has placed in the folder.** Read every page of each. Give one summary per article, in the order he gave them. When there is more than one article, end with the section `## Across these articles` (see 4).

**Pages that are pictures of text** (a scan: the page has no selectable text).
- If you can read the page images: summarize as usual, and make the first line of the summary exactly `Scanned pages: quotes may contain reading errors`. Copy quotes character by character from what you see; do not tidy spelling or modernize.
- If you cannot read them: say the pages are unreadable to you, do not summarize, and ask for another copy (a PDF downloaded from the publisher, or a clearer scan).

**Zotero.** If Zotero tools are connected in this session, find the item there and read its attached PDF. If they are not, say Zotero is not connected yet (the guide has an optional step for it) and ask for the DOI or the PDF instead.

## 2. Read before writing

Go through the article and, for each of the seven sections below, copy out the sentences that carry it, each with its page number. Write the summary only from those sentences. If you find no sentence for something, the article does not say it: write `not stated`.

Page numbers: use the number printed on the page. If the pages carry no printed number, count from the first page of the PDF. Say which on the "Read from" line.

## 3. The summary

Use this shape exactly (the headings are fixed and always all seven, in this order):

```
# <Article title>
<Authors> (<year>). <Journal>, <volume>(<issue>). DOI: <doi>
Read from: <publisher PDF | repository copy (accepted manuscript) | web page>. Page numbers: <as printed | counted from the first PDF page>.

## Research question
- <detail in your words> (p. 3: "word-for-word quote")

## Site, region and period
## Materials and methods
## Evidence
## Argument
## Significance
## Limits
```

Rules for every detail:

- **One detail, one bullet, one citation.** Each bullet ends with `(p. N: "quote")`: the page number, then a short quote copied word for word from that page. One page per citation; if two pages are needed, give two citations.
- **The quote must be on that page, exactly as written.** Keep it short (about 5 to 25 words), a continuous run of the article's own words. No joining of separate passages, no ellipses, no corrected spelling, no translated or paraphrased "quotes".
- **No quote, then it is an inference.** If a detail is your own reading and no sentence states it, end the bullet with `(inference)` and say what it rests on. Use this sparingly.
- **Web text without page numbers:** cite the section heading in place of the page: `(§ Results: "quote")`.
- **Missing items read `not stated`.** For example an article with no excavation site: `- not stated`. Do not fill a section from general knowledge.
- **Keep the author's hedges.** If the article says "may", "suggests", "in this sample", "preliminary", the detail says so too. Do not turn "was found in these 14 burials" into "is found in burials". Do not widen the claim beyond the sites, samples, periods or numbers studied, and keep past tense for what was found. (Summaries by language models overgeneralize far more often than human ones; this is the main error to avoid.)
- **Only the article.** Nothing from memory of other work, reviews, or the abstract of a different version.
- **Limits** lists what the authors themselves name as limits; your own doubts go there too but labelled `(inference)`.

Default size: one to three details per section, the article's most important ones. Settings in `memory/SETTINGS.md` may change length, tone, order and which sections come first; follow them. Settings never remove the page number and quote: a shorter summary has fewer details, each still cited.

## 4. Several articles

After the individual summaries:

```
## Across these articles
**Agreements**
- <point> (<Author year>, p. N; <Author year>, p. N)
**Disagreements**
- <point: who says what> (<Author year>, p. N; <Author year>, p. N)
```

Compare only on what the summaries above support. If the articles do not address the same question, say so in one line instead of forcing a comparison.

## 5. After the summary

End with one short line inviting him to dig into a section or push back. Then follow the `discussion-memory` skill: save what was covered under its subject, without being asked and without mentioning it unless something he said earlier is relevant.
